package com.skull1.hackathon1.Front;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.skull1.hackathon1.News.NewsActivity;
import com.skull1.hackathon1.R;
import com.tomer.fadingtextview.FadingTextView;


public class HomeFragment extends Fragment implements View.OnClickListener {

    View view;
    Button button1,button2;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_home, container, false);

        button1 = (Button) view.findViewById(R.id.official);
        button2 = (Button) view.findViewById(R.id.aefi);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent browserIntent= new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.india.gov.in/topics/home-affairs-enforcement/police"));
                startActivity(browserIntent);

            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Intent browserIntent= new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.punjabpolice.gov.in/eGovernance.aspx"));
                startActivity(browserIntent);

            }
        });

        return view;
    }


    @Override
    public void onClick(View v) {

    }
}