package com.skull1.hackathon1.Selections;

public class InfantDetails {

    private String vaccineName;
    private String vaccineDet;
    private String vaccineDose;
    private int vaccineImage;

    public String getVaccineName() {
        return vaccineName;
    }

    public String getVaccineDet() {
        return vaccineDet;
    }

    public String getVaccineDose() {
        return vaccineDose;
    }

    public int getVaccineImage() {
        return vaccineImage;
    }

    public InfantDetails(String vaccineName, String vaccineDet, String vaccineDose, int vaccineImage){

        this.vaccineName = vaccineName;
        this.vaccineDet = vaccineDet;
        this.vaccineDose = vaccineDose;
        this.vaccineImage = vaccineImage;


    }

}
