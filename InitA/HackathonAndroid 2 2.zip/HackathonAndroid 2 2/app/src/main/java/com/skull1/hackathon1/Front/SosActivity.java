package com.skull1.hackathon1.Front;



import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.net.Uri;

import android.os.Bundle;
import android.se.omapi.Session;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.skull1.hackathon1.R;
import com.uber.sdk.rides.client.SessionConfiguration;

public class SosActivity extends AppCompatActivity {
    private static final int REQUEST_CALL = 1;
    private EditText mEditTextNumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sos);
        //SessionConfiguration sessionConfiguration=new SessionConfiguration.Builder().setClientId("5JxbR9oiwAp7yqbvU208Am1FCDJOkPe3").setServerToken().setRedirectUri()


        ImageView imageCall = findViewById(R.id.image_call);

        imageCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makePhoneCall();
            }
        });

        final MediaPlayer sirenMP = MediaPlayer.create(this,R.raw.siren);
        Button playSiren = (Button) this.findViewById(R.id.siren);
        playSiren.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sirenMP.start();

            }

        });
        Button ol = (Button) this.findViewById(R.id.olas);
        ol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Intent browserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.olacabs.com/mobile"));
                //startActivity(browserIntent);
                Intent i=getPackageManager().getLaunchIntentForPackage("https://m.uber.com/ul/?client_id=5JxbR9oiwAp7yqbvU208Am1FCDJOkPe3");
                startActivity(i);
            }

        });
    }

    private void makePhoneCall() {
        String number = "8218521910" ;   //mEditTextNumber.getText().toString();
        if (number.trim().length() > 0) {

            if (ContextCompat.checkSelfPermission(SosActivity.this,
                    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(SosActivity.this,
                        new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL);
            } else {
                String dial = "tel:" + number;
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
            }

        } else {
            Toast.makeText(SosActivity.this, "Enter Phone Number", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CALL) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makePhoneCall();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }
}