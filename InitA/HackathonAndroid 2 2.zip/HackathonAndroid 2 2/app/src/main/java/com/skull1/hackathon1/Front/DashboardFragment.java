package com.skull1.hackathon1.Front;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.skull1.hackathon1.News.NewsActivity;
import com.skull1.hackathon1.R;


public class DashboardFragment extends Fragment implements View.OnClickListener {

    View view;
    Button  news,maps,sms,hardware,login,defence;
    ImageView profilePic;

    Toolbar toolbar = null;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_dashboard, container, false);
        news = (Button) view.findViewById(R.id.dashnews);
        maps = (Button) view.findViewById(R.id.dashmap);
        sms = (Button) view.findViewById(R.id.dashsms);
        hardware = (Button) view.findViewById(R.id.dashsos);
        login = (Button) view.findViewById(R.id.dashlogin);
        defence = (Button) view.findViewById(R.id.dashfight);
        profilePic = (ImageView) view.findViewById(R.id.profilepic);


        Toolbar toolbar = view.findViewById(R.id.toolbar);



        ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("DashBoard");

        news.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent h= new Intent(getActivity(), NewsActivity.class);
                startActivity(h);

            }
        });
        maps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent h= new Intent(getActivity(), MapActivity.class);
                startActivity(h);

            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent h= new Intent(getActivity(), loginpage.class);
                startActivity(h);

            }
        });
        sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent h= new Intent(getActivity(), MessageMainActivity.class);
                startActivity(h);

            }
        });
        defence.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent h= new Intent(getActivity(), InfantActivity.class);
                startActivity(h);

            }
        });
        hardware.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent h= new Intent(getActivity(), MainXActivity.class);
                startActivity(h);

            }
        });
        profilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Fragment profileFragment = new ProfileFragment();
                FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container,profileFragment).addToBackStack("tag");
                fragmentTransaction.commit();




            }
        });
        return view;
    }










    @Override
    public void onClick(View v) {

    }
}