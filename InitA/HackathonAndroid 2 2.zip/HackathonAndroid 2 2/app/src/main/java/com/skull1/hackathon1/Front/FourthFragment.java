package com.skull1.hackathon1.Front;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.skull1.hackathon1.R;

public class FourthFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view= inflater.inflate(R.layout.fragmentfourth,container,false);
        ImageView imageview=(ImageView) view.findViewById(R.id.back_button_profile);

        setRetainInstance(true);

        imageview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){

                Fragment dashboardFragment = new DashboardFragment();
                FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container,dashboardFragment);
                fragmentTransaction.commit();
            }
        });

        ImageView callButton =(ImageView) view.findViewById(R.id.call_button_profile);

        callButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                PackageManager packageManager=getActivity().getPackageManager();
                if (packageManager.hasSystemFeature(PackageManager.FEATURE_TELEPHONY)){
                    TextView e = getActivity().findViewById(R.id.call_profile_number);

                    Intent intent = new Intent(Intent.ACTION_CALL);
                    intent.setData(Uri.parse("tel:"+e.getText().toString()));
                    startActivity(intent);

                }
            }
        });

        return view;
    }




}
