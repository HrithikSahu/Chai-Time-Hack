package com.skull1.hackathon1.Front;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.skull1.hackathon1.Adapter.MyAdapter;
import com.skull1.hackathon1.R;
import com.skull1.hackathon1.Selections.InfantDetails;

import java.util.ArrayList;
import java.util.List;

public class InfantActivity extends AppCompatActivity {
    RecyclerView mRecyclerView;
    List<InfantDetails> myInfantList;
    InfantDetails mInfantDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infant);

        mRecyclerView = (RecyclerView)findViewById(R.id.recyclerView);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(InfantActivity.this,1);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        myInfantList = new ArrayList<>();

        mInfantDetails = new InfantDetails("Hammer strike","Using your car keys is one of the easiest ways to defend yourself.","Easy",R.drawable.pic1);
        myInfantList.add(mInfantDetails);

        mInfantDetails = new InfantDetails("Groin kick","making your escape possible.","Easy",R.drawable.pic2);
        myInfantList.add(mInfantDetails);
        mInfantDetails = new InfantDetails("Heel palm strike","This move can cause damage to the nose or throat.","Medium",R.drawable.pic3);
        myInfantList.add(mInfantDetails);
        mInfantDetails = new InfantDetails("Elbow strike","This may cause your attacker to loosen their grip, allowing you to run.","Hard",R.drawable.pic4);


        myInfantList.add(mInfantDetails);

        MyAdapter myAdapter = new MyAdapter(InfantActivity.this,myInfantList);
        mRecyclerView.setAdapter(myAdapter);

    }
}
