package com.skull1.hackathon1.Front;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;

import android.util.Log;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.skull1.hackathon1.News.NewsActivity;
import com.skull1.hackathon1.R;
import com.tomer.fadingtextview.FadingTextView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class HomeNew extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private FadingTextView fadingTextView;





    DrawerLayout drawer;
    NavigationView navigationView;
    Toolbar toolbar=null;

    boolean firstOpen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_new);

        Intent intent = getIntent();
        firstOpen= intent.getBooleanExtra("firstOpen",false);


        Toolbar toolbar = findViewById(R.id.toolbar);
        fadingTextView = findViewById(R.id.fading_text_view);

        setSupportActionBar(toolbar);

        getSupportActionBar().setTitle("Home");


        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView= (NavigationView)findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        Log.i("TAG", "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!onCreate: " + firstOpen);


        if(firstOpen==true){
            Intent loginIntent = new Intent(this,loginpage.class);

            startActivity(loginIntent);
        }

        else{
            loadFragment(new HomeFragment());
        }


        //getting bottom navigation view and attaching the listener
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(this::onNavigationItemSelected);





    }






    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_new, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        Fragment fragment = null;
        int id = item.getItemId();
        switch (id) {

            case R.id.register: {

                Intent h= new Intent(HomeNew.this, loginpage.class);
                startActivity(h);

                //do somthing
                break;
            }
            case R.id.maps: {

                Intent h= new Intent(HomeNew.this,PermissionsActivity.class);
                startActivity(h);

                //do somthing
                break;
            }
            case R.id.det: {

                Intent h= new Intent(HomeNew.this, InfantActivity.class);
                startActivity(h);

                //do somthing
                break;
            }
            case R.id.schedule: {

                Intent h= new Intent( HomeNew.this,EmailActivity.class);
                startActivity(h);

                //do somthing
                break;
            }

            case R.id.calan: {

                Intent h= new Intent( HomeNew.this,CalendarActivity.class);
                startActivity(h);

                //do somthing
                break;
            }

            case R.id.sosmenu: {

                Intent h= new Intent( HomeNew.this,SosActivity.class);
                startActivity(h);

                //do somthing
                break;
            }
            case R.id.shake: {

                Intent h= new Intent( HomeNew.this,MainXActivity.class);
                startActivity(h);

                //do somthing
                break;
            }
            case R.id.message: {

                Intent h= new Intent( HomeNew.this,MessageMainActivity.class);
                startActivity(h);

                //do somthing
                break;
            }

            case R.id.news: {

                Intent h= new Intent( HomeNew.this, NewsActivity.class);
                startActivity(h);

                //do somthing
                break;
            }

            case R.id.hard: {

                Intent i = getPackageManager().getLaunchIntentForPackage("com.dev.methk.arduinoandroid");
                startActivity(i);
                //do somthing
                break;
            }

            case R.id.navigation_home:{
                fragment = new HomeFragment();
                return loadFragment(fragment);

            }

            case R.id.navigation_dashboard: {
                fragment = new DashboardFragment();
                return loadFragment(fragment);
            }

            case R.id.navigation_Profile: {
                fragment = new ProfileFragment();
                return loadFragment(fragment);
            }

            case R.id.navigation: {
                fragment = new FourthFragment();
                return loadFragment(fragment);
            }



        }



        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }


}

